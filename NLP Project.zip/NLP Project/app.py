"""
================================================================================
PROJECT 17: DOCUMENT QUESTION ANSWERING (RAG APPLICATION)
================================================================================
STAGE 1: PROBLEM IDENTIFICATION
--------------------------------------------------------------------------------
Problem Statement:
    Organizations, universities, and enterprises maintain large volumes of
    institutional PDFs, policy handbooks, technical manuals, and SOPs. Manual
    keyword search (Ctrl+F) fails to capture semantic intent, struggles across
    multi-document collections, and forces users to read lengthy sections to
    synthesize simple answers.

Objective:
    Build an end-to-end Retrieval-Augmented Generation (RAG) web application
    that allows users to upload institutional PDF documents, automatically
    extract, clean, and chunk the text, index semantic vector embeddings in
    FAISS, retrieve the most relevant passages for any natural-language query,
    and generate accurate, source-grounded answers using Google Gemini.

Real-World Applications:
    - University student handbooks, academic regulations, and exam policy Q&A
    - Enterprise HR onboarding manuals and compliance document assistants
    - Engineering, hardware, and software troubleshooting manual search
    - Legal contract review and institutional audit support

Architecture & Tech Stack:
    - Frontend / GUI   : Streamlit
    - PDF Parsing      : pypdf
    - Text Chunking    : LangChain (RecursiveCharacterTextSplitter)
    - Embeddings       : Google Gemini API (gemini-embedding-001, 768-dim)
    - Vector Database  : FAISS (IndexFlatIP over L2-normalized vectors = Cosine)
    - Generator LLM    : Google Gemini API (gemini-3.7-flash via Interactions API)
================================================================================
"""

from __future__ import annotations

import hashlib
import io
import os
import re
import time
import unicodedata
from collections import Counter
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

import faiss
import numpy as np
import pandas as pd
import streamlit as st
from dotenv import load_dotenv
from google import genai
from google.genai import types
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter
from pypdf import PdfReader

# Load environment variables (e.g., GEMINI_API_KEY) from a local .env file if present
load_dotenv()

# ==============================================================================
# GLOBAL CONSTANTS & MODEL CONFIGURATION
# ==============================================================================
EMBEDDING_MODEL = "gemini-embedding-001"
GENERATION_MODEL = "gemini-3.7-flash"
EMBEDDING_DIM = 768
EMBEDDING_BATCH_SIZE = 32

# Lightweight built-in English stopword set for Stage 4/5 NLP preprocessing & EDA
# (Avoids external NLTK runtime downloads so the app works immediately offline/online)
ENGLISH_STOPWORDS = frozenset(
    {
        "a", "about", "above", "after", "again", "against", "all", "am", "an",
        "and", "any", "are", "as", "at", "be", "because", "been", "before",
        "being", "below", "between", "both", "but", "by", "can", "could", "did",
        "do", "does", "doing", "down", "during", "each", "few", "for", "from",
        "further", "had", "has", "have", "having", "he", "her", "here", "hers",
        "herself", "him", "himself", "his", "how", "i", "if", "in", "into",
        "is", "it", "its", "itself", "just", "may", "me", "might", "more",
        "most", "must", "my", "myself", "no", "nor", "not", "now", "of", "off",
        "on", "once", "only", "or", "other", "our", "ours", "ourselves", "out",
        "over", "own", "same", "shall", "she", "should", "so", "some", "such",
        "than", "that", "the", "their", "theirs", "them", "themselves", "then",
        "there", "these", "they", "this", "those", "through", "to", "too",
        "under", "until", "up", "very", "was", "we", "were", "what", "when",
        "where", "which", "while", "who", "whom", "why", "will", "with",
        "would", "you", "your", "yours", "yourself", "yourselves", "also",
        "page", "section", "document", "using", "used", "use", "one", "two",
    }
)


# ==============================================================================
# DATA STRUCTURES
# ==============================================================================
@dataclass
class UploadedPDFRecord:
    """Represents a validated uploaded PDF file with basic metadata."""
    filename: str
    size_kb: float
    raw_bytes: bytes
    sha256: str


@dataclass
class ExtractionStats:
    """Tracks document extraction and cleaning quality metrics."""
    total_files: int = 0
    total_pages: int = 0
    valid_pages: int = 0
    empty_or_skipped_pages: int = 0
    duplicate_pages_removed: int = 0
    warnings: List[str] = field(default_factory=list)


@dataclass
class RetrievedChunk:
    """Represents a retrieved text chunk along with its cosine similarity score."""
    document: Document
    similarity_score: float
    rank: int


# ==============================================================================
# STAGE 2: DATASET HANDLING (PDF UPLOAD & VALIDATION)
# ==============================================================================
def load_uploaded_pdfs(uploaded_files: Sequence[Any]) -> Tuple[List[UploadedPDFRecord], List[str]]:
    """
    Validate and ingest user-uploaded PDF files from Streamlit's file uploader.

    Handles:
        - Empty file uploads (0 bytes)
        - Non-PDF file signatures (checks %PDF magic header)
        - Duplicate file uploads via SHA-256 content hashing

    Args:
        uploaded_files: Sequence of Streamlit UploadedFile objects.

    Returns:
        Tuple of (list of valid UploadedPDFRecord objects, list of warning messages).
    """
    records: List[UploadedPDFRecord] = []
    warnings: List[str] = []
    seen_hashes: set[str] = set()

    for file_obj in uploaded_files:
        filename = getattr(file_obj, "name", "unnamed.pdf")
        try:
            raw_bytes = file_obj.getvalue()
        except Exception as exc:
            warnings.append(f"Could not read '{filename}': {exc}")
            continue

        if not raw_bytes:
            warnings.append(f"Skipped '{filename}': file is empty (0 bytes).")
            continue

        if not raw_bytes.lstrip().startswith(b"%PDF"):
            warnings.append(f"Skipped '{filename}': invalid PDF header.")
            continue

        file_hash = hashlib.sha256(raw_bytes).hexdigest()
        if file_hash in seen_hashes:
            warnings.append(f"Skipped duplicate upload: '{filename}'.")
            continue

        seen_hashes.add(file_hash)
        records.append(
            UploadedPDFRecord(
                filename=filename,
                size_kb=round(len(raw_bytes) / 1024.0, 2),
                raw_bytes=raw_bytes,
                sha256=file_hash,
            )
        )

    return records, warnings


# ==============================================================================
# STAGE 3: DATA EXTRACTION & CLEANING
# ==============================================================================
def clean_extracted_text(raw_text: str) -> str:
    """
    Clean and normalize noisy text extracted from institutional PDFs and manuals.

    Cleaning operations performed:
        1. Unicode NFKC normalization (fixes ligatures like 'fi'/'fl' and smart quotes).
        2. Removal of non-printable control characters and null bytes.
        3. De-hyphenation of words split across line breaks (e.g., 'docu-\\nment' -> 'document').
        4. Removal of standalone page-number artifacts (e.g., 'Page 4 of 20').
        5. Whitespace normalization while preserving paragraph boundaries.

    Args:
        raw_text: Raw string returned by PDF text extraction.

    Returns:
        Cleaned, normalized text string.
    """
    if not raw_text:
        return ""

    # 1. Unicode normalization
    text = unicodedata.normalize("NFKC", raw_text)

    # 2. Remove null bytes and control characters (preserve \n and \t)
    text = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]", " ", text)

    # 3. Normalize Windows/Mac line endings to Unix newlines
    text = text.replace("\r\n", "\n").replace("\r", "\n")

    # 4. Rejoin hyphenated line-wraps (common in two-column PDFs and manuals)
    text = re.sub(r"([A-Za-z])-\n([A-Za-z])", r"\1\2", text)

    # 5. Strip isolated 'Page X of Y' lines
    text = re.sub(r"(?im)^\s*page\s+\d+(\s+of\s+\d+)?\s*$", "", text)

    # 6. Collapse repeated spaces/tabs on each line and limit consecutive blank lines
    lines = [re.sub(r"[ \t]+", " ", line).strip() for line in text.split("\n")]
    text = "\n".join(lines)
    text = re.sub(r"\n{3,}", "\n\n", text)

    return text.strip()


def extract_and_clean_pdfs(
    pdf_records: Sequence[UploadedPDFRecord],
    min_page_chars: int = 25,
) -> Tuple[List[Document], ExtractionStats]:
    """
    Extract text page-by-page from validated PDFs, clean inconsistencies,
    filter empty/scanned pages, and deduplicate identical page content.

    Args:
        pdf_records: Validated UploadedPDFRecord instances.
        min_page_chars: Minimum cleaned character count required to keep a page.

    Returns:
        Tuple of (list of page-level LangChain Documents, ExtractionStats summary).
    """
    page_documents: List[Document] = []
    stats = ExtractionStats(total_files=len(pdf_records))
    seen_page_hashes: set[str] = set()

    for record in pdf_records:
        try:
            reader = PdfReader(io.BytesIO(record.raw_bytes))
            if reader.is_encrypted:
                try:
                    reader.decrypt("")
                except Exception:
                    stats.warnings.append(
                        f"'{record.filename}' is password-protected and could not be decrypted."
                    )
                    continue
        except Exception as exc:
            stats.warnings.append(f"Failed to parse '{record.filename}': {exc}")
            continue

        num_pages = len(reader.pages)
        stats.total_pages += num_pages

        for page_idx, page in enumerate(reader.pages, start=1):
            try:
                raw_text = page.extract_text() or ""
            except Exception as exc:
                stats.empty_or_skipped_pages += 1
                stats.warnings.append(
                    f"Extraction error on '{record.filename}' page {page_idx}: {exc}"
                )
                continue

            cleaned_text = clean_extracted_text(raw_text)

            # Skip blank pages or image-only scanned pages without embedded text
            if len(cleaned_text) < min_page_chars:
                stats.empty_or_skipped_pages += 1
                continue

            # Deduplicate repeated boilerplate/cover pages
            page_hash = hashlib.md5(cleaned_text.lower().encode("utf-8")).hexdigest()
            if page_hash in seen_page_hashes:
                stats.duplicate_pages_removed += 1
                continue

            seen_page_hashes.add(page_hash)
            stats.valid_pages += 1
            page_documents.append(
                Document(
                    page_content=cleaned_text,
                    metadata={
                        "source": record.filename,
                        "page": page_idx,
                        "total_pages": num_pages,
                        "char_count": len(cleaned_text),
                    },
                )
            )

    return page_documents, stats


# ==============================================================================
# STAGE 4: TEXT PREPROCESSING (TOKENIZATION, NORMALIZATION, CHUNKING)
# ==============================================================================
def tokenize_and_normalize(text: str, remove_stopwords: bool = True) -> List[str]:
    """
    Perform lowercase normalization, regex word tokenization, and optional
    stopword removal for NLP analysis (EDA and token-level evaluation).

    Note:
        Dense semantic embeddings (Gemini) benefit from preserving full natural
        grammar and stopwords inside chunks, whereas stopword-filtered tokens
        are used for Exploratory Data Analysis (Stage 5) and evaluation metrics
        (Stage 8).

    Args:
        text: Input text string.
        remove_stopwords: Whether to filter common English stopwords.

    Returns:
        List of normalized alphanumeric tokens.
    """
    normalized = unicodedata.normalize("NFKC", text).lower()
    tokens = re.findall(r"\b[a-z0-9]{2,}\b", normalized)
    if remove_stopwords:
        return [tok for tok in tokens if tok not in ENGLISH_STOPWORDS and not tok.isdigit()]
    return tokens


def chunk_documents(
    page_documents: Sequence[Document],
    chunk_size: int = 1000,
    chunk_overlap: int = 200,
) -> List[Document]:
    """
    Split page-level documents into overlapping, semantically coherent chunks
    using LangChain's RecursiveCharacterTextSplitter.

    Separators are applied hierarchically (paragraphs -> lines -> sentences ->
    words -> characters) so sections remain intact whenever possible.

    Args:
        page_documents: Cleaned page-level LangChain Document objects.
        chunk_size: Maximum character length per chunk.
        chunk_overlap: Character overlap between consecutive chunks to preserve
            cross-boundary context.

    Returns:
        List of chunked LangChain Document objects enriched with chunk metadata.
    """
    if not page_documents:
        return []

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        length_function=len,
        separators=["\n\n", "\n", ". ", "? ", "! ", "; ", ", ", " ", ""],
    )

    raw_chunks = splitter.split_documents(list(page_documents))

    # Deduplicate near-identical chunks and assign sequential metadata
    processed_chunks: List[Document] = []
    seen_chunk_hashes: set[str] = set()

    for idx, chunk in enumerate(raw_chunks, start=1):
        content = chunk.page_content.strip()
        if not content:
            continue

        chunk_hash = hashlib.md5(content.lower().encode("utf-8")).hexdigest()
        if chunk_hash in seen_chunk_hashes:
            continue
        seen_chunk_hashes.add(chunk_hash)

        tokens = tokenize_and_normalize(content, remove_stopwords=False)
        chunk.page_content = content
        chunk.metadata = {
            **chunk.metadata,
            "chunk_id": len(processed_chunks) + 1,
            "word_count": len(tokens),
            "char_length": len(content),
        }
        processed_chunks.append(chunk)

    return processed_chunks


# ==============================================================================
# STAGE 5: EXPLORATORY DATA ANALYSIS (EDA)
# ==============================================================================
def compute_corpus_eda(chunks: Sequence[Document]) -> Dict[str, Any]:
    """
    Compute exploratory data analysis statistics over the processed corpus
    for visual inspection in the Streamlit dashboard and academic reporting.

    Args:
        chunks: Processed text chunks.

    Returns:
        Dictionary containing corpus metrics, chunk length distribution DataFrame,
        per-document summary DataFrame, and top-keyword frequency DataFrame.
    """
    if not chunks:
        return {}

    char_lengths = [c.metadata.get("char_length", len(c.page_content)) for c in chunks]
    word_counts = [c.metadata.get("word_count", len(c.page_content.split())) for c in chunks]

    all_informative_tokens: List[str] = []
    per_doc_counter: Dict[str, Dict[str, Any]] = {}

    for chunk in chunks:
        src = chunk.metadata.get("source", "Unknown")
        page = chunk.metadata.get("page", 1)
        tokens = tokenize_and_normalize(chunk.page_content, remove_stopwords=True)
        all_informative_tokens.extend(tokens)

        if src not in per_doc_counter:
            per_doc_counter[src] = {"Document": src, "Pages Indexed": set(), "Chunks": 0, "Total Words": 0}
        per_doc_counter[src]["Pages Indexed"].add(page)
        per_doc_counter[src]["Chunks"] += 1
        per_doc_counter[src]["Total Words"] += chunk.metadata.get("word_count", 0)

    top_keywords = Counter(all_informative_tokens).most_common(15)
    keywords_df = pd.DataFrame(top_keywords, columns=["Keyword", "Frequency"]).set_index("Keyword")

    doc_summary_rows = [
        {
            "Document": row["Document"],
            "Pages Indexed": len(row["Pages Indexed"]),
            "Chunks": row["Chunks"],
            "Total Words": row["Total Words"],
        }
        for row in per_doc_counter.values()
    ]
    doc_summary_df = pd.DataFrame(doc_summary_rows)

    chunk_lengths_df = pd.DataFrame(
        {
            "Chunk #": [c.metadata.get("chunk_id", i + 1) for i, c in enumerate(chunks)],
            "Characters": char_lengths,
            "Words": word_counts,
        }
    ).set_index("Chunk #")

    return {
        "total_chunks": len(chunks),
        "total_words": int(sum(word_counts)),
        "unique_keywords": len(set(all_informative_tokens)),
        "avg_chunk_chars": round(float(np.mean(char_lengths)), 1),
        "min_chunk_chars": int(min(char_lengths)),
        "max_chunk_chars": int(max(char_lengths)),
        "keywords_df": keywords_df,
        "doc_summary_df": doc_summary_df,
        "chunk_lengths_df": chunk_lengths_df,
    }


# ==============================================================================
# STAGE 6: FEATURE ENGINEERING (GEMINI EMBEDDINGS + FAISS VECTOR STORE)
# ==============================================================================
class GeminiFAISSVectorStore:
    """
    Dense semantic vector store powered by Google Gemini embeddings
    (`gemini-embedding-001`) and Facebook AI Similarity Search (`FAISS`).

    Uses task-specific asymmetric embeddings:
        - Documents: task_type='RETRIEVAL_DOCUMENT'
        - Queries  : task_type='RETRIEVAL_QUERY'

    Vectors are L2-normalized before indexing in `faiss.IndexFlatIP`, ensuring
    that inner product search equals exact Cosine Similarity in [-1.0, 1.0].
    """

    def __init__(
        self,
        client: genai.Client,
        embedding_model: str = EMBEDDING_MODEL,
        embedding_dim: int = EMBEDDING_DIM,
    ) -> None:
        self.client = client
        self.embedding_model = embedding_model
        self.embedding_dim = embedding_dim
        self.index: Optional[faiss.IndexFlatIP] = None
        self.documents: List[Document] = []

    @staticmethod
    def _l2_normalize(matrix: np.ndarray) -> np.ndarray:
        """Normalize embedding vectors to unit L2 norm for cosine similarity."""
        norms = np.linalg.norm(matrix, axis=1, keepdims=True)
        norms = np.where(norms == 0.0, 1.0, norms)
        return (matrix / norms).astype("float32")

    def _embed_texts(self, texts: List[str], task_type: str) -> np.ndarray:
        """Generate normalized dense vector embeddings in batches via Gemini API."""
        all_vectors: List[List[float]] = []

        for start in range(0, len(texts), EMBEDDING_BATCH_SIZE):
            batch = texts[start : start + EMBEDDING_BATCH_SIZE]
            response = self.client.models.embed_content(
                model=self.embedding_model,
                contents=batch,
                config=types.EmbedContentConfig(
                    task_type=task_type,
                    output_dimensionality=self.embedding_dim,
                ),
            )
            if not response.embeddings:
                raise RuntimeError("Gemini embedding API returned an empty embedding list.")
            all_vectors.extend([emb.values for emb in response.embeddings])

        matrix = np.asarray(all_vectors, dtype="float32")
        return self._l2_normalize(matrix)

    def build_index(self, documents: Sequence[Document]) -> int:
        """
        Embed all document chunks and populate a FAISS IndexFlatIP vector index.

        Args:
            documents: Sequence of chunked LangChain Documents.

        Returns:
            Total number of indexed vectors.
        """
        if not documents:
            raise ValueError("Cannot build vector index from an empty document list.")

        self.documents = list(documents)
        texts = [doc.page_content for doc in self.documents]
        vectors = self._embed_texts(texts, task_type="RETRIEVAL_DOCUMENT")

        dim = vectors.shape[1]
        self.index = faiss.IndexFlatIP(dim)
        self.index.add(vectors)
        return self.index.ntotal

    def similarity_search(
        self,
        query: str,
        top_k: int = 4,
        min_similarity: float = 0.0,
    ) -> List[RetrievedChunk]:
        """
        Retrieve the top-K semantically closest chunks for a user question.

        Args:
            query: Natural-language question from the user.
            top_k: Maximum number of passages to retrieve.
            min_similarity: Minimum cosine similarity score threshold [0.0, 1.0].

        Returns:
            Ranked list of RetrievedChunk objects.
        """
        if self.index is None or not self.documents:
            raise RuntimeError("Vector index has not been built yet.")

        query_vec = self._embed_texts([query], task_type="RETRIEVAL_QUERY")
        k = min(top_k, len(self.documents))
        scores, indices = self.index.search(query_vec, k)

        results: List[RetrievedChunk] = []
        for rank, (score, doc_idx) in enumerate(zip(scores[0], indices[0]), start=1):
            if doc_idx < 0 or doc_idx >= len(self.documents):
                continue
            sim = float(score)
            if sim < min_similarity:
                continue
            results.append(
                RetrievedChunk(
                    document=self.documents[doc_idx],
                    similarity_score=sim,
                    rank=rank,
                )
            )
        return results


# ==============================================================================
# STAGE 7: MODEL DEVELOPMENT (RAG RETRIEVER + GEMINI LLM GENERATOR)
# ==============================================================================
RAG_SYSTEM_INSTRUCTION = """You are an expert institutional Document Question Answering assistant.
Follow these rules strictly:
1. Answer the user's question using ONLY the information provided in the Retrieved Document Context below.
2. Do NOT hallucinate, speculate, or use outside knowledge not supported by the context.
3. Cite your sources inline immediately after factual statements using the format: [Source: <filename>, Page <page>].
4. If the retrieved context does not contain enough information to answer the question, explicitly reply:
   "The uploaded documents do not contain sufficient information to answer this question."
5. Keep answers clear, well-structured, concise, and directly responsive to the question."""


class DocumentQARAGModel:
    """
    End-to-end Retrieval-Augmented Generation (RAG) model uniting dense FAISS
    semantic retrieval with Google Gemini (`gemini-3.7-flash`) via the modern
    Interactions API (`client.interactions.create`).
    """

    def __init__(
        self,
        client: genai.Client,
        vector_store: GeminiFAISSVectorStore,
        generation_model: str = GENERATION_MODEL,
    ) -> None:
        self.client = client
        self.vector_store = vector_store
        self.generation_model = generation_model

    @staticmethod
    def _format_context(retrieved_chunks: Sequence[RetrievedChunk]) -> str:
        """Serialize retrieved passages with explicit file and page metadata."""
        formatted_blocks = []
        for item in retrieved_chunks:
            meta = item.document.metadata
            header = (
                f"[Excerpt {item.rank} | Source: {meta.get('source', 'Unknown')} | "
                f"Page: {meta.get('page', '?')} | Chunk ID: {meta.get('chunk_id', '?')} | "
                f"Similarity: {item.similarity_score:.3f}]"
            )
            formatted_blocks.append(f"{header}\n{item.document.page_content}")
        return "\n\n---\n\n".join(formatted_blocks)

    def answer_question(
        self,
        question: str,
        top_k: int = 4,
        min_similarity: float = 0.25,
        max_output_tokens: int = 1024,
    ) -> Dict[str, Any]:
        """
        Execute the full Retrieve -> Augment -> Generate pipeline.

        Args:
            question: User question string.
            top_k: Number of top chunks to retrieve from FAISS.
            min_similarity: Minimum cosine similarity threshold.
            max_output_tokens: Maximum tokens for the generated response.

        Returns:
            Dictionary containing the answer, retrieved chunks, latency, and
            automatic grounding metrics.
        """
        start_time = time.perf_counter()

        # Step 1: Retrieve relevant document chunks
        retrieved = self.vector_store.similarity_search(
            query=question,
            top_k=top_k,
            min_similarity=min_similarity,
        )

        if not retrieved:
            elapsed = round(time.perf_counter() - start_time, 2)
            return {
                "question": question,
                "answer": (
                    "No sufficiently relevant sections were found in the uploaded documents "
                    f"(minimum similarity threshold: {min_similarity:.2f}). Try rephrasing your "
                    "question or lowering the similarity threshold in the sidebar."
                ),
                "sources": [],
                "latency_sec": elapsed,
                "grounding_metrics": {
                    "mean_similarity": 0.0,
                    "top_similarity": 0.0,
                    "context_precision": 0.0,
                    "context_recall": 0.0,
                    "context_f1": 0.0,
                },
            }

        # Step 2: Augment prompt with retrieved passages
        context_block = self._format_context(retrieved)
        augmented_prompt = (
            f"### Retrieved Document Context\n{context_block}\n\n"
            f"### User Question\n{question}\n\n"
            f"### Grounded Answer (with inline [Source: filename, Page X] citations):"
        )

        # Step 3: Generate grounded answer using Gemini Interactions API
        interaction = self.client.interactions.create(
            model=self.generation_model,
            system_instruction=RAG_SYSTEM_INSTRUCTION,
            input=augmented_prompt,
            generation_config={"max_output_tokens": max_output_tokens},
        )
        answer_text = (interaction.output_text or "").strip()
        if not answer_text:
            answer_text = "The model did not return a text response. Please try again."

        elapsed = round(time.perf_counter() - start_time, 2)

        # Step 4: Compute automatic grounding / retrieval validation metrics (Stage 8)
        grounding_metrics = evaluate_rag_grounding(answer_text, retrieved)

        return {
            "question": question,
            "answer": answer_text,
            "sources": retrieved,
            "latency_sec": elapsed,
            "grounding_metrics": grounding_metrics,
        }


# ==============================================================================
# STAGE 8: MODEL EVALUATION (FAITHFULNESS, PRECISION, RECALL, F1-SCORE, EM)
# ==============================================================================
def compute_token_prf1(predicted: str, reference: str) -> Dict[str, float]:
    """
    Compute standard SQuAD-style Token-Level Precision, Recall, F1-Score,
    and normalized Exact Match (EM) between a predicted answer and a reference.

    Args:
        predicted: Generated answer string.
        reference: Ground-truth answer or reference context string.

    Returns:
        Dictionary with exact_match, precision, recall, and f1_score in [0.0, 1.0].
    """
    pred_tokens = tokenize_and_normalize(predicted, remove_stopwords=False)
    ref_tokens = tokenize_and_normalize(reference, remove_stopwords=False)

    exact_match = 1.0 if (" ".join(pred_tokens) == " ".join(ref_tokens) and len(ref_tokens) > 0) else 0.0

    if not pred_tokens or not ref_tokens:
        return {"exact_match": exact_match, "precision": 0.0, "recall": 0.0, "f1_score": 0.0}

    pred_counts = Counter(pred_tokens)
    ref_counts = Counter(ref_tokens)
    overlap = sum((pred_counts & ref_counts).values())

    if overlap == 0:
        return {"exact_match": exact_match, "precision": 0.0, "recall": 0.0, "f1_score": 0.0}

    precision = overlap / len(pred_tokens)
    recall = overlap / len(ref_tokens)
    f1_score = (2.0 * precision * recall) / (precision + recall)

    return {
        "exact_match": round(exact_match, 4),
        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "f1_score": round(f1_score, 4),
    }


def evaluate_rag_grounding(
    answer: str,
    retrieved_chunks: Sequence[RetrievedChunk],
) -> Dict[str, float]:
    """
    Evaluate RAG answer quality without needing a manual gold label:
        - Top-1 & Mean Cosine Similarity of retrieved passages
        - Lexical Grounding Precision (fraction of informative answer tokens
          supported directly by retrieved source text — detects hallucination)
        - Lexical Context Recall & Grounding F1
    """
    if not retrieved_chunks:
        return {
            "mean_similarity": 0.0,
            "top_similarity": 0.0,
            "context_precision": 0.0,
            "context_recall": 0.0,
            "context_f1": 0.0,
        }

    similarities = [item.similarity_score for item in retrieved_chunks]
    combined_context = " ".join(item.document.page_content for item in retrieved_chunks)

    # Strip inline citation tags before checking lexical grounding against passages
    cleaned_answer = re.sub(r"\[Source:[^\]]+\]", "", answer)
    ans_tokens = tokenize_and_normalize(cleaned_answer, remove_stopwords=True)
    ctx_token_set = set(tokenize_and_normalize(combined_context, remove_stopwords=True))

    if ans_tokens and ctx_token_set:
        supported = sum(1 for tok in ans_tokens if tok in ctx_token_set)
        ctx_precision = supported / len(ans_tokens)
        unique_ans_set = set(ans_tokens)
        ctx_recall = len(unique_ans_set & ctx_token_set) / len(ctx_token_set)
        ctx_f1 = (
            (2 * ctx_precision * ctx_recall) / (ctx_precision + ctx_recall)
            if (ctx_precision + ctx_recall) > 0
            else 0.0
        )
    else:
        ctx_precision = ctx_recall = ctx_f1 = 0.0

    return {
        "mean_similarity": round(float(np.mean(similarities)), 4),
        "top_similarity": round(float(max(similarities)), 4),
        "context_precision": round(ctx_precision, 4),
        "context_recall": round(ctx_recall, 4),
        "context_f1": round(ctx_f1, 4),
    }


# ==============================================================================
# STAGE 10: TESTING & IMPLEMENTATION (BUILT-IN PIPELINE SMOKE TESTS)
# ==============================================================================
def run_pipeline_unit_tests() -> List[Dict[str, str]]:
    """
    Execute fast, deterministic unit tests verifying cleaning, chunking,
    L2 normalization, FAISS cosine retrieval, and evaluation metric accuracy.
    """
    results: List[Dict[str, str]] = []

    # Test 1: Cleaning de-hyphenation & page number stripping
    dirty = "Exam reg-\nulations apply.\nPage 3 of 12\n\n\nMinimum attendance is 75%."
    cleaned = clean_extracted_text(dirty)
    t1_pass = ("regulations" in cleaned) and ("Page 3 of 12" not in cleaned)
    results.append(
        {
            "Test Case": "Stage 3: Text Cleaning & De-hyphenation",
            "Status": "PASS" if t1_pass else "FAIL",
            "Details": f"Cleaned output length: {len(cleaned)} chars",
        }
    )

    # Test 2: Recursive Chunking preserves metadata
    sample_doc = Document(
        page_content=("Policy rule details. " * 120),
        metadata={"source": "handbook.pdf", "page": 2},
    )
    chunks = chunk_documents([sample_doc], chunk_size=300, chunk_overlap=50)
    t2_pass = len(chunks) > 1 and all(c.metadata.get("source") == "handbook.pdf" for c in chunks)
    results.append(
        {
            "Test Case": "Stage 4: Chunking & Metadata Preservation",
            "Status": "PASS" if t2_pass else "FAIL",
            "Details": f"Generated {len(chunks)} chunks with intact source/page metadata",
        }
    )

    # Test 3: FAISS L2-Normalized Cosine Similarity Search
    vec_a = GeminiFAISSVectorStore._l2_normalize(np.array([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]], dtype="float32"))
    idx = faiss.IndexFlatIP(3)
    idx.add(vec_a)
    q_vec = GeminiFAISSVectorStore._l2_normalize(np.array([[0.98, 0.02, 0.0]], dtype="float32"))
    scores, ids = idx.search(q_vec, 1)
    t3_pass = int(ids[0][0]) == 0 and float(scores[0][0]) > 0.99
    results.append(
        {
            "Test Case": "Stage 6: FAISS Cosine Similarity Indexing",
            "Status": "PASS" if t3_pass else "FAIL",
            "Details": f"Top match idx={ids[0][0]}, cosine={scores[0][0]:.4f}",
        }
    )

    # Test 4: SQuAD Evaluation Metrics (Precision, Recall, F1)
    metrics = compute_token_prf1("Minimum attendance is 75 percent", "The minimum attendance is 75 percent")
    t4_pass = metrics["precision"] == 1.0 and 0.85 < metrics["f1_score"] < 1.0
    results.append(
        {
            "Test Case": "Stage 8: Evaluation Metrics (Precision/Recall/F1)",
            "Status": "PASS" if t4_pass else "FAIL",
            "Details": f"P={metrics['precision']:.2f}, R={metrics['recall']:.2f}, F1={metrics['f1_score']:.2f}",
        }
    )

    return results


# ==============================================================================
# STAGE 9: GUI DEVELOPMENT (STREAMLIT WEB APPLICATION)
# ==============================================================================
def init_session_state() -> None:
    """Initialize persistent Streamlit session state keys."""
    defaults = {
        "vector_store": None,
        "chunks": [],
        "extraction_stats": None,
        "eda_summary": {},
        "indexed_signature": None,
        "last_result": None,
        "qa_history": [],
    }
    for key, default_value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = default_value


def render_app() -> None:
    """Render the complete Streamlit GUI for Document Question Answering."""
    st.set_page_config(
        page_title="DocQA — Institutional Document Question Answering (RAG)",
        page_icon="📄",
        layout="wide",
        initial_sidebar_state="expanded",
    )
    init_session_state()

    # --- Header Banner ---
    st.title("📄 Document Question Answering (Project 17)")
    st.caption(
        "End-to-End Retrieval-Augmented Generation (RAG) Application • "
        f"Embeddings: `{EMBEDDING_MODEL}` + FAISS • Generator: `{GENERATION_MODEL}`"
    )

    # --- Sidebar Configuration ---
    with st.sidebar:
        st.header("⚙️ Configuration")

        api_key = os.getenv("GEMINI_API_KEY", "").strip()
        if api_key:
            st.success("🔑 Gemini API Key Active (Loaded from `.env`)")
        else:
            st.error("⚠️ `GEMINI_API_KEY` not found in `.env`. Please check your `.env` file.")

        st.divider()
        st.subheader("📐 Preprocessing & Retrieval")
        chunk_size = st.slider("Chunk Size (characters)", min_value=300, max_value=2000, value=1000, step=100)
        chunk_overlap = st.slider("Chunk Overlap (characters)", min_value=0, max_value=500, value=200, step=50)
        top_k = st.slider("Top-K Source Chunks", min_value=1, max_value=10, value=4, step=1)
        min_similarity = st.slider(
            "Minimum Cosine Similarity",
            min_value=0.0,
            max_value=0.90,
            value=0.25,
            step=0.05,
            help="Filter out low-relevance document chunks below this cosine score.",
        )

        st.divider()
        st.subheader("📊 Knowledge Base Status")
        if st.session_state["vector_store"] is not None:
            stats: ExtractionStats = st.session_state["extraction_stats"]
            st.success("Index Ready")
            st.write(f"- **Files Indexed:** {stats.total_files}")
            st.write(f"- **Valid Pages:** {stats.valid_pages} / {stats.total_pages}")
            st.write(f"- **Text Chunks:** {len(st.session_state['chunks'])}")
        else:
            st.info("No documents indexed yet. Upload PDFs to begin.")

    # --- Mandatory GUI Feature 1: PDF File Uploader ---
    st.subheader("1️⃣ Upload Institutional PDFs or Manuals")
    uploaded_files = st.file_uploader(
        "Upload one or more PDF documents (handbooks, policy manuals, reports, SOPs):",
        type=["pdf"],
        accept_multiple_files=True,
    )

    col_idx_btn, col_idx_info = st.columns([1, 3])
    with col_idx_btn:
        process_clicked = st.button("⚙️ Process & Index Documents", type="primary", use_container_width=True)
    with col_idx_info:
        if uploaded_files:
            st.caption(
                f"{len(uploaded_files)} file(s) selected: "
                + ", ".join(f"`{f.name}`" for f in uploaded_files)
            )
        else:
            st.caption("Upload PDF files above and click **Process & Index Documents** to build the vector index.")

    # Execute Stages 2 -> 6 when user clicks Process & Index Documents
    if process_clicked:
        if not api_key:
            st.error("Gemini API Key is missing. Please ensure `GEMINI_API_KEY` is configured in your project's `.env` file.")
        elif not uploaded_files:
            st.warning("Please upload at least one PDF document first.")
        else:
            try:
                with st.status("Running RAG Ingestion Pipeline (Stages 2–6)...", expanded=True) as status:
                    st.write("Stage 2: Validating uploaded PDF files...")
                    records, upload_warnings = load_uploaded_pdfs(uploaded_files)
                    for w in upload_warnings:
                        st.warning(w)
                    if not records:
                        st.error("No valid PDF files remained after validation.")
                        status.update(label="Ingestion failed", state="error")
                        st.stop()

                    st.write("Stage 3: Extracting and cleaning PDF text page-by-page...")
                    page_docs, ext_stats = extract_and_clean_pdfs(records)
                    for w in ext_stats.warnings:
                        st.warning(w)
                    if not page_docs:
                        st.error(
                            "No extractable text found. If these are scanned image PDFs, "
                            "run OCR first before uploading."
                        )
                        status.update(label="No text extracted", state="error")
                        st.stop()

                    st.write(f"Stage 4: Chunking {len(page_docs)} clean page(s) (size={chunk_size}, overlap={chunk_overlap})...")
                    chunks = chunk_documents(page_docs, chunk_size=chunk_size, chunk_overlap=chunk_overlap)

                    st.write("Stage 5: Computing Exploratory Data Analysis (EDA) statistics...")
                    eda_summary = compute_corpus_eda(chunks)

                    st.write(f"Stage 6: Generating `{EMBEDDING_MODEL}` embeddings & building FAISS index...")
                    client = genai.Client(api_key=api_key)
                    vector_store = GeminiFAISSVectorStore(client=client)
                    n_vectors = vector_store.build_index(chunks)

                    # Save artifacts into session state
                    st.session_state["vector_store"] = vector_store
                    st.session_state["chunks"] = chunks
                    st.session_state["extraction_stats"] = ext_stats
                    st.session_state["eda_summary"] = eda_summary
                    st.session_state["last_result"] = None
                    st.session_state["indexed_signature"] = [r.sha256 for r in records]

                    status.update(
                        label=f"Indexed {n_vectors} chunks from {ext_stats.total_files} PDF(s) successfully!",
                        state="complete",
                        expanded=False,
                    )
            except Exception as exc:
                st.error(f"Error during document processing: {exc}")

    st.divider()

    # --- Main Application Tabs ---
    tab_qa, tab_eda, tab_eval = st.tabs(
        [
            "💬 Ask Questions (RAG Q&A)",
            "📊 Corpus EDA & Preprocessing",
            "🧪 Evaluation & System Tests",
        ]
    )

    # ==========================================================================
    # TAB 1: MANDATORY Q&A INTERFACE
    # ==========================================================================
    with tab_qa:
        st.subheader("2️⃣ Ask a Question About Your Documents")

        # Mandatory GUI Feature 2: Question input text box
        question = st.text_input(
            "Enter your question:",
            placeholder="e.g., What is the minimum attendance requirement or refund policy?",
            key="question_input",
        )

        # Mandatory GUI Feature 3: "Ask Question" button
        ask_clicked = st.button("Ask Question", type="primary")

        if ask_clicked:
            if not api_key:
                st.error("Gemini API Key is missing. Please ensure `GEMINI_API_KEY` is configured in your project's `.env` file.")
            elif st.session_state["vector_store"] is None:
                st.warning("Please upload and process at least one PDF document first.")
            elif not question.strip():
                st.warning("Please type a question before clicking 'Ask Question'.")
            else:
                try:
                    with st.spinner(f"Retrieving relevant passages & querying `{GENERATION_MODEL}`..."):
                        client = genai.Client(api_key=api_key)
                        rag_model = DocumentQARAGModel(
                            client=client,
                            vector_store=st.session_state["vector_store"],
                        )
                        result = rag_model.answer_question(
                            question=question.strip(),
                            top_k=top_k,
                            min_similarity=min_similarity,
                        )
                        st.session_state["last_result"] = result
                        st.session_state["qa_history"].insert(0, result)
                except Exception as exc:
                    st.error(f"Error generating answer: {exc}")

        # Mandatory GUI Feature 4 & 5: Display generated answer + relevant document sources
        if st.session_state["last_result"] is not None:
            res = st.session_state["last_result"]
            gm = res["grounding_metrics"]

            st.markdown("### ✅ Generated Answer")
            with st.container(border=True):
                st.markdown(res["answer"])

            # Validation metrics bar
            m1, m2, m3, m4 = st.columns(4)
            m1.metric("Top Cosine Similarity", f"{gm['top_similarity']:.3f}")
            m2.metric("Mean Retrieval Score", f"{gm['mean_similarity']:.3f}")
            m3.metric("Grounding Precision", f"{gm['context_precision'] * 100:.1f}%")
            m4.metric("Response Latency", f"{res['latency_sec']:.2f}s")

            # Mandatory GUI Feature 5: Relevant Document Sections & Source References
            st.markdown("### 📚 Relevant Document Sections & Source References")
            if not res["sources"]:
                st.info("No matching document sections exceeded the similarity threshold.")
            else:
                for item in res["sources"]:
                    meta = item.document.metadata
                    label = (
                        f"Rank #{item.rank} — 📄 {meta.get('source', 'Unknown')} | "
                        f"Page {meta.get('page', '?')} | Chunk #{meta.get('chunk_id', '?')} | "
                        f"Cosine Similarity: {item.similarity_score:.4f}"
                    )
                    with st.expander(label, expanded=(item.rank == 1)):
                        st.markdown(f"**Source File:** `{meta.get('source', 'Unknown')}`  \n"
                                    f"**Page:** `{meta.get('page', '?')}` of `{meta.get('total_pages', '?')}`  \n"
                                    f"**Chunk Word Count:** `{meta.get('word_count', '?')}`")
                        st.code(item.document.page_content, language=None)

        # Previous Q&A History
        if len(st.session_state["qa_history"]) > 1:
            with st.expander(f"🕒 Previous Questions ({len(st.session_state['qa_history']) - 1})"):
                for past in st.session_state["qa_history"][1:]:
                    st.markdown(f"**Q:** {past['question']}")
                    st.markdown(f"**A:** {past['answer']}")
                    st.divider()

    # ==========================================================================
    # TAB 2: STAGE 5 — EXPLORATORY DATA ANALYSIS (EDA)
    # ==========================================================================
    with tab_eda:
        st.subheader("Exploratory Data Analysis (EDA) on Uploaded Corpus")
        eda = st.session_state.get("eda_summary")
        ext_stats: Optional[ExtractionStats] = st.session_state.get("extraction_stats")

        if not eda or ext_stats is None:
            st.info("Upload and index PDF documents to visualize corpus EDA metrics and charts.")
        else:
            c1, c2, c3, c4 = st.columns(4)
            c1.metric("Total Chunks", eda["total_chunks"])
            c2.metric("Total Words", f"{eda['total_words']:,}")
            c3.metric("Avg Chunk Length", f"{eda['avg_chunk_chars']} chars")
            c4.metric("Skipped / Duplicate Pages", ext_stats.empty_or_skipped_pages + ext_stats.duplicate_pages_removed)

            st.markdown("#### Per-Document Extraction Summary")
            st.dataframe(eda["doc_summary_df"], use_container_width=True, hide_index=True)

            chart_col1, chart_col2 = st.columns(2)
            with chart_col1:
                st.markdown("#### Top 15 Informative Terms (Post-Stopword Removal)")
                st.bar_chart(eda["keywords_df"])
            with chart_col2:
                st.markdown("#### Chunk Character Length Distribution")
                st.bar_chart(eda["chunk_lengths_df"][["Characters"]])

            with st.expander("🔍 Inspect Sample Preprocessed Chunks"):
                for sample_chunk in st.session_state["chunks"][:5]:
                    st.markdown(
                        f"**Chunk #{sample_chunk.metadata['chunk_id']}** "
                        f"(`{sample_chunk.metadata['source']}`, Page {sample_chunk.metadata['page']})"
                    )
                    st.caption(sample_chunk.page_content[:400] + ("..." if len(sample_chunk.page_content) > 400 else ""))

    # ==========================================================================
    # TAB 3: STAGE 8 (EVALUATION) & STAGE 10 (TESTING)
    # ==========================================================================
    with tab_eval:
        st.subheader("Stage 8: Reference-Based Answer Evaluation (SQuAD Metrics)")
        st.write(
            "Compare the latest RAG-generated answer against a ground-truth reference answer "
            "from your PDF to compute **Exact Match (Accuracy)**, **Precision**, **Recall**, and **F1-Score**."
        )

        last_res = st.session_state.get("last_result")
        if last_res:
            st.markdown(f"**Evaluated Question:** {last_res['question']}")
            st.info(last_res["answer"])
            reference_answer = st.text_area(
                "Enter Ground-Truth Reference Answer (from the PDF):",
                placeholder="Paste the expected correct answer here to calculate Precision, Recall, and F1-Score...",
            )
            if st.button("Compute Evaluation Metrics"):
                if not reference_answer.strip():
                    st.warning("Please enter a reference answer first.")
                else:
                    clean_pred = re.sub(r"\[Source:[^\]]+\]", "", last_res["answer"]).strip()
                    scores = compute_token_prf1(clean_pred, reference_answer.strip())
                    e1, e2, e3, e4 = st.columns(4)
                    e1.metric("Exact Match (EM)", f"{scores['exact_match'] * 100:.1f}%")
                    e2.metric("Token Precision", f"{scores['precision'] * 100:.1f}%")
                    e3.metric("Token Recall", f"{scores['recall'] * 100:.1f}%")
                    e4.metric("Token F1-Score", f"{scores['f1_score'] * 100:.1f}%")
        else:
            st.info("Ask at least one question in the **Ask Questions** tab to unlock reference evaluation.")

        st.divider()
        st.subheader("Stage 10: Automated Pipeline Unit Tests")
        if st.button("Run Pipeline Unit Tests"):
            test_rows = run_pipeline_unit_tests()
            st.dataframe(pd.DataFrame(test_rows), use_container_width=True, hide_index=True)
            if all(r["Status"] == "PASS" for r in test_rows):
                st.success("All 4 core pipeline unit tests passed!")
            else:
                st.error("One or more unit tests failed. Review details above.")


if __name__ == "__main__":
    render_app()
