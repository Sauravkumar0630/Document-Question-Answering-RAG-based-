# 10-Slide PowerPoint Presentation Content
## Project 17: Document Question Answering Using Retrieval-Augmented Generation (RAG)

---

### Slide 1: Project Title & Team Members
**Title:** Project 17: Document Question Answering System (RAG)  
**Subtitle:** Intelligent Q&A over Institutional PDFs & Manuals using Google Gemini, LangChain, FAISS & Streamlit

**On-Slide Content:**
- **Course / Subject:** Natural Language Processing (NLP) Capstone Project
- **Project ID:** Project 17 — Document Question Answering
- **Team Members:**
  - [Member 1 Name] — [Roll Number] (Backend & RAG Pipeline)
  - [Member 2 Name] — [Roll Number] (Data Extraction, Cleaning & EDA)
  - [Member 3 Name] — [Roll Number] (Streamlit GUI, Evaluation & Testing)
- **Faculty Guide:** [Professor / Instructor Name]
- **Date:** [Presentation Date]

**Speaker Notes:**
> Good morning/afternoon everyone. Today our team is presenting Project 17: an end-to-end Document Question Answering web application powered by Retrieval-Augmented Generation, or RAG. Our system enables users to upload institutional PDFs and manuals, ask natural-language questions, and receive accurate, source-cited answers in real time through an interactive Streamlit interface.

---

### Slide 2: Problem Statement & Objectives
**Title:** Problem Statement & Project Objectives

**On-Slide Content:**
- **Problem Statement:**
  - Institutional knowledge is locked inside lengthy PDF handbooks, academic regulations, SOPs, and technical manuals.
  - Standard keyword search (`Ctrl+F`) misses synonyms, fails across multiple documents, and cannot synthesize answers.
  - Standalone LLMs lack access to private institutional files and are prone to factual hallucinations.
- **Core Objectives:**
  - Build a fully functional web-based RAG application (Streamlit GUI) for multi-PDF question answering.
  - Implement a clean 10-stage NLP pipeline: ingestion, text cleaning, chunking, semantic embedding, FAISS retrieval, and Gemini generation.
  - Ensure transparency by displaying exact source filenames, page numbers, similarity scores, and verbatim supporting excerpts.

**Speaker Notes:**
> Why do we need this system? Students, employees, and engineers spend hours hunting through dense PDF manuals for specific rules or procedures. Keyword search fails when the user's phrasing differs from the document's exact wording, while general-purpose LLMs don't know private institutional policies and can fabricate answers. Our objective was to build an end-to-end RAG application that grounds every answer directly in uploaded PDFs and shows verifiable page-level citations.

---

### Slide 3: Introduction & Real-World Applications
**Title:** Introduction to RAG & Real-World Applications

**On-Slide Content:**
- **What is Retrieval-Augmented Generation (RAG)?**
  - Combines **Information Retrieval** (finding relevant passages via vector similarity) with **Generative AI** (synthesizing clear answers strictly from retrieved text).
  - Eliminates expensive model fine-tuning when documents change—simply re-index new PDFs.
- **Real-World Applications:**
  - **Higher Education:** Instant Q&A over university handbooks, exam regulations, and syllabus manuals.
  - **Enterprise HR & Operations:** Employee onboarding manuals, leave policies, and compliance SOPs.
  - **Technical Support:** Hardware/software user guides and troubleshooting manuals.
  - **Legal & Healthcare:** Contract clause lookup and institutional protocol verification.

**Speaker Notes:**
> RAG bridges the gap between static document repositories and conversational AI. Instead of retraining a model whenever a policy changes, we dynamically retrieve only the most relevant document chunks and pass them to the LLM as grounded context. This architecture is widely deployed across universities, enterprise HR portals, technical support desks, and compliance teams.

---

### Slide 4: Dataset Description
**Title:** Dataset Description: Institutional PDFs & Manuals

**On-Slide Content:**
- **Data Source:** User-uploaded unstructured PDF documents (institutional handbooks, policy manuals, academic brochures, and technical guides).
- **Document Characteristics:**
  - Multi-page, heterogeneous layouts (headings, bullet lists, tables, footnotes, headers/footers).
  - Unstructured natural language ranging from 5 to 200+ pages per document.
- **Dataset Validation & Ingestion (`Stage 2`):**
  - Multi-file upload support via Streamlit (`accept_multiple_files=True`).
  - File integrity verification (non-empty check, `%PDF` magic-byte header check).
  - SHA-256 content hashing to automatically prevent duplicate document ingestion.
  - Metadata preservation: filename, file size (KB), page number, and total page count.

**Speaker Notes:**
> Unlike static CSV datasets, real-world Document QA operates on dynamic, unstructured PDF corpora. We tested our pipeline on institutional handbooks and technical manuals. During ingestion, our loader validates file headers, gracefully handles encrypted or corrupted PDFs, deduplicates repeated uploads using SHA-256 hashes, and preserves exact filename and page metadata for downstream citations.

---

### Slide 5: Data Preprocessing & Exploratory Data Analysis (EDA)
**Title:** Data Cleaning, Preprocessing & Corpus EDA

**On-Slide Content:**
- **Data Extraction & Cleaning (`Stage 3`):**
  - Page-by-page extraction using `pypdf`.
  - Unicode NFKC normalization (fixes ligatures and encoding quirks) & control-character removal.
  - De-hyphenation across line wraps (`reg-\nulations` -> `regulations`) and removal of `Page X of Y` footers.
  - Filtering blank/scanned pages (<25 chars) and MD5 deduplication of repeated cover/boilerplate pages.
- **Preprocessing & Chunking (`Stage 4`):**
  - LangChain `RecursiveCharacterTextSplitter` (`chunk_size = 1000`, `chunk_overlap = 200`).
  - Hierarchical splitting (`\n\n` -> `\n` -> `. ` -> words) preserves sentence and paragraph coherence.
- **Built-in EDA Dashboard (`Stage 5`):**
  - Visualizes total chunks, word counts, chunk character-length histograms, and Top-15 informative keywords (post-stopword removal).

**Speaker Notes:**
> PDF text is notoriously messy—it contains broken hyphenated words, stray page numbers, and empty scanned pages. Our cleaning module resolves these issues before chunking. We chose a 1,000-character chunk size with a 200-character overlap using LangChain's RecursiveCharacterTextSplitter so ideas aren't cut off mid-sentence. Additionally, our app features an interactive EDA tab showing corpus statistics, chunk length distributions, and top domain terms after stopword removal.

---

### Slide 6: Feature Engineering & Methodology
**Title:** Feature Engineering: Dense Embeddings & Vector Database

**On-Slide Content:**
- **From Text to Semantic Vectors (`Stage 6`):**
  - Traditional Bag-of-Words / TF-IDF only match exact words and miss semantic meaning.
  - We use **Google Gemini Embeddings (`gemini-embedding-001`)** to project each chunk into a **768-dimensional** dense semantic vector space.
- **Asymmetric Task-Specific Embedding:**
  - Document chunks embedded with `task_type = RETRIEVAL_DOCUMENT`.
  - User questions embedded with `task_type = RETRIEVAL_QUERY`.
- **Vector Indexing with FAISS:**
  - All vectors are **L2-normalized** to unit length (`||v|| = 1`).
  - Indexed in **`faiss.IndexFlatIP`** (Inner Product over unit vectors = exact **Cosine Similarity** in `[-1, 1]`).
  - Enables millisecond top-K retrieval with a configurable minimum similarity threshold.

**Speaker Notes:**
> For feature engineering, dense neural embeddings outperform TF-IDF because they capture semantic similarity—for example, matching a question about "tuition reimbursement" to a passage discussing "fee refund rules." We use Gemini's `gemini-embedding-001` model with asymmetric task types for documents versus queries, L2-normalize the 768-dimensional vectors, and store them in FAISS `IndexFlatIP` so retrieval computes exact cosine similarity in milliseconds.

---

### Slide 7: Model Architecture & Algorithms
**Title:** Model Architecture & End-to-End RAG Pipeline

**On-Slide Content:**
- **Two-Stage RAG Architecture (`Stage 7`):**
  1. **Retriever:** Embeds the user's question -> performs Top-K cosine similarity search in FAISS -> filters passages below the minimum similarity threshold.
  2. **Generator:** Injects ranked passages (with source & page tags) into a strictly grounded prompt sent to **`gemini-3.8-flash`** via the official **`google-genai` Interactions API**.
- **Anti-Hallucination Guardrails:**
  - Strict system instruction: answer **only** from retrieved context.
  - Mandatory inline citations: `[Source: filename.pdf, Page X]`.
  - Explicit fallback refusal when documents lack the requested information.
- **Why This Stack?**
  - Low latency, zero hallucination drift, modular Python design, and verifiable source attribution.

**Speaker Notes:**
> Here is how the complete RAG model operates at inference time. When the user clicks "Ask Question," the query is embedded and matched against our FAISS index to retrieve the Top-K most relevant chunks. Those passages are assembled with their file and page metadata and passed to `gemini-3.8-flash` via the Interactions API. Crucially, our system instruction enforces strict grounding: if the answer isn't in the PDFs, the model explicitly states so instead of guessing.

---

### Slide 8: Performance Evaluation & Results
**Title:** Performance Evaluation, Metrics & Unit Testing

**On-Slide Content:**
- **Dual Evaluation Strategy (`Stage 8`):**
  1. **Live Reference-Free Grounding Metrics (Every Query):**
     - **Top-1 & Mean Cosine Similarity:** Measures retrieval relevance.
     - **Grounding Precision:** Percentage of informative answer tokens directly supported by retrieved passages (hallucination check).
     - **End-to-End Response Latency:** Tracked per query in seconds.
  2. **SQuAD-Style Reference Evaluation (Benchmarking Tab):**
     - Evaluates generated answers against ground-truth PDF answers using **Exact Match (EM)**, **Token Precision**, **Token Recall**, and **Token F1-Score**.
- **Automated Testing (`Stage 10`):**
  - 4 built-in unit tests validate text cleaning, metadata-preserving chunking, FAISS cosine search, and Precision/Recall/F1 calculation directly inside the UI.

**Speaker Notes:**
> Validating a RAG system requires measuring both retrieval quality and answer faithfulness. On every question, our GUI displays the Top-1 and Mean Cosine Similarity of retrieved chunks alongside a Grounding Precision score and response latency. Furthermore, our Evaluation tab lets evaluators enter a ground-truth answer from the PDF to compute standard SQuAD metrics—Exact Match, Precision, Recall, and F1-Score—and run 4 automated unit tests verifying every pipeline stage.

---

### Slide 9: GUI Screenshots & Working Demonstration
**Title:** Streamlit Web GUI & Live Demonstration

**On-Slide Content:**
- **Mandatory GUI Features Implemented (`Stage 9`):**
  - **PDF File Uploader** + *"Process & Index Documents"* status tracker.
  - **Question Input Text Box** & **"Ask Question"** primary action button.
  - **Generated Answer Panel** with inline citations and grounding metrics.
  - **Relevant Document Sections & Source References** (expandable cards with filename, page, chunk ID, cosine score, and verbatim snippet).
  - **Additional Tabs:** Corpus EDA Dashboard & Reference Evaluation / Unit Tests.
- **[PLACEHOLDER 1 — Insert Screenshot of PDF Upload & Q&A Output with Source References]**
- **[PLACEHOLDER 2 — Insert Screenshot of Corpus EDA Charts & Evaluation Tab]**
- **Live Demo Plan:** Upload institutional PDF -> Index -> Ask factual question -> Verify cited page -> Ask out-of-scope question to demonstrate refusal guardrail.

**Speaker Notes:**
> This slide highlights our Streamlit web interface. Rather than a static notebook, users interact with a clean, multi-tab web application. Let's now switch to our live Streamlit demo: we will upload a sample institutional PDF, process and index it, ask an in-scope policy question to verify the exact page citation, and then ask an out-of-scope question to prove the model refuses to hallucinate.

---

### Slide 10: Conclusion & Future Scope
**Title:** Conclusion, Limitations & Future Scope

**On-Slide Content:**
- **Conclusion:**
  - Successfully built an end-to-end, production-structured **Document Question Answering (RAG)** system covering all 10 NLP development stages.
  - Delivers fast, accurate, and verifiable answers over institutional PDFs with full source transparency and interactive evaluation.
- **Current Limitations:**
  - Scanned image-only PDFs require OCR before text extraction.
  - Complex multi-column tables may lose visual alignment during plain-text extraction.
- **Future Scope:**
  - **Multimodal RAG:** Direct PDF visual + table embeddings using `gemini-embedding-2` and native OCR support.
  - **Hybrid Search & Re-Ranking:** Combine BM25 lexical search with FAISS dense retrieval + cross-encoder re-ranking.
  - **Persistent Multi-User Vector DB:** Migrate to persistent ChromaDB / Qdrant with multi-turn conversational memory and role-based access control.

**Speaker Notes:**
> To conclude, we delivered a complete, demonstrable RAG application that transforms static institutional PDFs into an interactive, trustworthy Q&A assistant. While plain-text extraction currently has limitations on scanned image PDFs and complex tables, our modular architecture is ready to scale—future upgrades include multimodal PDF embeddings with Gemini Embedding 2, hybrid BM25 + dense re-ranking, and persistent multi-user vector storage. Thank you—we are now open for questions!
