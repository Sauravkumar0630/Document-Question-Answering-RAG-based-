# 📄 Project 17: Document Question Answering (RAG Application)

An end-to-end **Retrieval-Augmented Generation (RAG)** web application built with **Python, Streamlit, LangChain, FAISS, and the Google Gemini API** (`gemini-embedding-001` & `gemini-3.8-flash`). Users can upload institutional PDFs, policy handbooks, or technical manuals and ask natural-language questions to receive accurate, citation-grounded answers along with exact source passages.

---

## 🎯 Project Objective

Institutional documents (university regulations, HR manuals, SOPs, and technical guides) often span dozens or hundreds of pages. Traditional `Ctrl+F` keyword search fails on paraphrased questions and provides no synthesized answers. This application solves that problem by combining **dense semantic retrieval (FAISS + Gemini Embeddings)** with **grounded LLM generation (Gemini 3.8 Flash)** in an interactive Streamlit web GUI.

---

## 🏗️ System Architecture & 10-Stage NLP Pipeline

```text
┌────────────────────┐     ┌───────────────────────┐     ┌──────────────────────────┐
│  1. PDF Uploads    │ ──► │ 2. Text Extraction &  │ ──► │ 3. Recursive Chunking    │
│  (Streamlit UI)    │     │    Cleaning (pypdf)   │     │    (LangChain Splitter)  │
└────────────────────┘     └───────────────────────┘     └─────────────┬────────────┘
                                                                       │
                                                                       ▼
┌────────────────────┐     ┌───────────────────────┐     ┌──────────────────────────┐
│ 6. Answer + Source │ ◄── │ 5. Grounded Answer    │ ◄── │ 4. Dense Embeddings      │
│    Citations UI    │     │    (gemini-3.8-flash) │     │    (gemini-embedding-001)│
└────────────────────┘     └───────────▲───────────┘     │    + FAISS IndexFlatIP   │
                                       │                 └─────────────┬────────────┘
                                       │                               │
                           ┌───────────┴───────────┐                   │
                           │  Top-K Relevant       │ ◄─────────────────┘
                           │  Document Passages    │ ◄── User Question (Query Embedding)
                           └───────────────────────┘
```

### Coverage of All 10 Mandatory Development Stages
1. **Problem Identification:** Defined institutional PDF QA challenges, RAG objectives, and real-world use cases in `app.py`.
2. **Dataset Collection & Handling:** Supports multi-PDF uploads of institutional handbooks/manuals with magic-byte validation and SHA-256 deduplication.
3. **Data Cleaning:** Performs Unicode NFKC normalization, de-hyphenation across line breaks, control-character removal, page-number stripping, and blank/duplicate page filtering.
4. **Text Preprocessing:** Applies regex tokenization, stopword filtering (for EDA & evaluation), and hierarchical chunking via LangChain's `RecursiveCharacterTextSplitter` (default: 1,000 chars, 200-char overlap).
5. **Exploratory Data Analysis (EDA):** Interactive dashboard tab displaying corpus metrics, per-document word/chunk tables, top-15 informative keywords, and chunk length distributions.
6. **Feature Engineering:** Generates 768-dimensional task-specific dense embeddings (`RETRIEVAL_DOCUMENT` / `RETRIEVAL_QUERY`) using `gemini-embedding-001`, L2-normalized and indexed in `FAISS IndexFlatIP` for exact Cosine Similarity search.
7. **Model Development:** Integrates the FAISS retriever with `gemini-3.8-flash` (Google GenAI Interactions API) using strict grounding system instructions and inline `[Source: filename, Page X]` citations.
8. **Model Evaluation:** Computes live Grounding Precision, Top-1 & Mean Cosine Similarity, and SQuAD-style Exact Match (EM), Token Precision, Token Recall, and F1-Score against reference answers.
9. **GUI Development:** Full Streamlit web application featuring PDF upload, question input box, "Ask Question" button, answer display, source citations, EDA tab, and evaluation tab.
10. **Testing & Implementation:** Includes built-in automated unit tests (`run_pipeline_unit_tests()`) directly executable from the UI.

---

## 📁 Repository Structure

```text
document-qa-rag/
├── app.py                # Complete modular Streamlit RAG application (Stages 1–10)
├── requirements.txt      # Pinned Python dependencies
├── README.md             # Project documentation & setup guide
├── PPT_Content.md        # 10-slide presentation deck content & speaker notes
├── .env.example          # Template for GEMINI_API_KEY
├── .gitignore            # Excludes .env, .venv, __pycache__, etc.
└── screenshots/          # Add working GUI screenshots here before submission
    ├── 01_upload_index.png
    ├── 02_qa_sources.png
    ├── 03_eda_dashboard.png
    └── 04_evaluation_tests.png
```

---

## ⚙️ Local Setup & Execution Guide

### Prerequisites
- Python **3.10 or higher**
- A free or paid **Google Gemini API Key** from [Google AI Studio](https://aistudio.google.com/apikey)

### Step 1: Clone the Repository
```bash
git clone https://github.com/<your-username>/document-qa-rag.git
cd document-qa-rag
```

### Step 2: Create & Activate a Virtual Environment

**Windows (PowerShell):**
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

**macOS / Linux:**
```bash
python3 -m venv .venv
source .venv/bin/activate
```

### Step 3: Install Dependencies
```bash
pip install -r requirements.txt
```
> **Note:** This project uses the current official **`google-genai`** SDK (`>= 2.3.0`), which replaces the deprecated `google-generativeai` library.

### Step 4: Configure Your Gemini API Key
Create a `.env` file in the project root (or enter the key directly in the app sidebar):
```env
GEMINI_API_KEY=your_google_gemini_api_key_here
```

### Step 5: Run the Streamlit Application
```bash
streamlit run app.py
```
Your browser will automatically open at `http://localhost:8501`.

### Step 6: Using the Application
1. Enter your **Gemini API Key** in the left sidebar (if not loaded from `.env`).
2. Upload one or more institutional PDF documents (e.g., university handbook, product manual, policy PDF).
3. Click **"Process & Index Documents"** to extract, clean, chunk, embed, and index the PDFs in FAISS.
4. Type a question into the **Enter your question** box and click **"Ask Question"**.
5. Review the grounded answer, confidence/similarity metrics, and expandable **Relevant Document Sections & Source References**.

---

## 📸 Working GUI Screenshots

> **Submission Checklist:** Replace the placeholder paths below with actual screenshots captured while running `streamlit run app.py` before pushing to GitHub.

### 1. PDF Upload & Vector Indexing Pipeline
![PDF Upload and Indexing](screenshots/01_upload_index.png)
*Caption: Uploading institutional PDFs and running the 6-stage ingestion & FAISS indexing pipeline.*

### 2. Question Answering & Source Citations
![Question Answering with Sources](screenshots/02_qa_sources.png)
*Caption: Grounded answer generated by `gemini-3.8-flash` with inline citations, cosine similarity scores, and verbatim source excerpts.*

### 3. Corpus EDA & Preprocessing Dashboard
![Corpus EDA Dashboard](screenshots/03_eda_dashboard.png)
*Caption: Exploratory Data Analysis displaying top informative keywords, chunk length distribution, and per-document statistics.*

### 4. Evaluation Metrics & Pipeline Unit Tests
![Evaluation and Unit Tests](screenshots/04_evaluation_tests.png)
*Caption: SQuAD-style Exact Match, Precision, Recall, F1-Score evaluation and automated pipeline unit tests.*

---

## 👥 Team Members
- **[Member 1 Name]** — Roll No. / Role
- **[Member 2 Name]** — Roll No. / Role
- **[Member 3 Name]** — Roll No. / Role

## 📜 License
Developed for academic and professional NLP project submission.
