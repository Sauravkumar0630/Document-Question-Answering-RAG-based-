@echo off
echo =======================================================================
echo Starting Project 17: Document Question Answering (Streamlit Web App)
echo =======================================================================
echo.

:: Detect Python executable
set "PY_EXE="
if exist "%LOCALAPPDATA%\Python\bin\python.exe" (
    set "PY_EXE=%LOCALAPPDATA%\Python\bin\python.exe"
) else (
    where py >nul 2>nul
    if %ERRORLEVEL% equ 0 (
        set "PY_EXE=py"
    ) else (
        set "PY_EXE=python"
    )
)

echo Using Python: %PY_EXE%

:: Check if virtual environment exists, if not create it
if not exist .venv (
    echo Creating virtual environment (.venv)...
    "%PY_EXE%" -m venv .venv
    echo Installing dependencies from requirements.txt...
    call .venv\Scripts\activate.bat
    pip install -r requirements.txt
) else (
    call .venv\Scripts\activate.bat
)

echo.
echo Launching Streamlit Web GUI...
streamlit run app.py
pause
